using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Your implemented technique inherits the InteractionTechnique class
public class MyTechnique : InteractionTechnique
{
    // You must implement your technique in this file
    // You need to assign the selected Object to the currentSelectedObject variable
    // Then it will be sent through a UnityEvent to another class for handling
    [SerializeField] private Transform controller; // Reference to the controller for ray alignment
    [SerializeField] private GameObject bubblePrefab; // Bubble visual prefab (for debugging)
    [SerializeField] private Material highlightMaterial; // Material for highlighted objects
    [SerializeField] private LineRenderer lineRenderer; // Reference to the LineRenderer
    private GameObject bubble; // The bubble instance
    private float bubbleRadius = 0.5f; // Initial radius of the bubble
    private float bubbleDistance = 2.0f; // Distance of the bubble from the controller

    private Material originalMaterial; // Store the original material of highlighted objects
    private GameObject highlightedObject; // Currently highlighted object
    private List<GameObject> objectsInBubble = new List<GameObject>(); // Objects inside the bubble
    private int highlightedIndex = 0; // Index of the currently highlighted object
    private bool isPreSelectionMode = false; // Indicates if pre-selection mode is active

    private void Start()
    {
        // TODO
        // Create a visual representation of the bubble
        bubble = Instantiate(bubblePrefab, controller.position + controller.forward * bubbleDistance, Quaternion.identity);
        bubble.transform.localScale = Vector3.one * bubbleRadius * 2.0f; // Scale based on bubble radius
        // Ensure the LineRenderer has 2 positions (start and end points)
        lineRenderer.positionCount = 2;
    }

    private void Update()
    {
        //TODO : Select a GameObject and assign it to the currentSelectedObject variable
        // Update the LineRenderer's positions every frame
        UpdateRay();

        UpdateBubblePosition();

        // Resize the bubble when holding the trigger and moving the joystick
        if (OVRInput.Get(OVRInput.Button.PrimaryHandTrigger, OVRInput.Controller.RTouch))
        {
            ResizeBubble();
        }

        // Move the bubble forward/backward with X/Y buttons
        MoveBubble();

        // Handle pre-selection mode
        HandlePreSelectionMode();


        // DO NOT REMOVE
        // If currentSelectedObject is not null, this will send it to the TaskManager for handling
        // Then it will set currentSelectedObject back to null
        base.CheckForSelection();
    }

    private void UpdateRay()
    {
        // Set the positions of the ray (controller to bubble)
        lineRenderer.SetPosition(0, controller.position); // Start point (controller)
        lineRenderer.SetPosition(1, bubble.transform.position); // End point (bubble)
    }

    private void UpdateBubblePosition()
    {
        Vector3 bubblePosition = controller.position + controller.forward * bubbleDistance;
        bubble.transform.position = bubblePosition;
        bubble.transform.localScale = Vector3.one * bubbleRadius * 2.0f;
    }

    private void ResizeBubble()
    {
        // Check if the squeeze button (trigger) is pressed
        if (OVRInput.Get(OVRInput.Axis1D.PrimaryHandTrigger, OVRInput.Controller.RTouch) > 0.1f)
        {
            // Get joystick input
            float joystickInput = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, OVRInput.Controller.RTouch).y;

            // Adjust bubble radius based on joystick input
            bubbleRadius += joystickInput * Time.deltaTime;

            // Clamp bubble radius to prevent extreme values
            bubbleRadius = Mathf.Clamp(bubbleRadius, 0.1f, 2.0f);
        }
    }

    private void MoveBubble()
    {
        if (OVRInput.Get(OVRInput.Button.One, OVRInput.Controller.RTouch)) // X button
        {
            bubbleDistance += Time.deltaTime;
        }
        else if (OVRInput.Get(OVRInput.Button.Two, OVRInput.Controller.RTouch)) // Y button
        {
            bubbleDistance -= Time.deltaTime;
        }

        bubbleDistance = Mathf.Clamp(bubbleDistance, 0.5f, 100.0f); // Clamp bubble distance
    }

    private void HandlePreSelectionMode()
    {
        if (OVRInput.GetDown(OVRInput.Button.PrimaryThumbstick , OVRInput.Controller.RTouch)) // Toggle pre-selection mode
        {
            isPreSelectionMode = !isPreSelectionMode;

            if (!isPreSelectionMode)
            {
                ExitPreSelectionMode();
            }
        }

        if (isPreSelectionMode)
        {
            DetectObjectsInBubble();

            if (objectsInBubble.Count > 0)
            {
                NavigateObjectsInBubble();

                // Select the highlighted object with the trigger
                if (OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, OVRInput.Controller.RTouch))
                {
                    SelectObject();
                }
            }
        }
    }

    private void DetectObjectsInBubble()
    {
        // Clear the previous list of objects
        objectsInBubble.Clear();

        // Find objects within the bubble using Physics.OverlapSphere
        Collider[] colliders = Physics.OverlapSphere(bubble.transform.position, bubbleRadius);

        foreach (var collider in colliders)
        {
            // Check if the object has a SelectableObject component
            if (collider.gameObject.GetComponent<SelectableObject>() != null)
            {
                // Measure the overlap percentage
                Bounds objectBounds = collider.bounds;
                Vector3 closestPointToBubble = objectBounds.ClosestPoint(bubble.transform.position);
                float distanceToBubbleCenter = Vector3.Distance(closestPointToBubble, bubble.transform.position);

                // Check if at least 70% of the object's volume is inside the bubble
                if (distanceToBubbleCenter < bubbleRadius * 0.7f)
                {
                    objectsInBubble.Add(collider.gameObject);
                }
            }
        }

        // Sort the objects by their distance to the bubble's center
        objectsInBubble.Sort((a, b) =>
            Vector3.Distance(a.transform.position, bubble.transform.position)
            .CompareTo(Vector3.Distance(b.transform.position, bubble.transform.position))
        );

        // Update the highlighted index if objects are found
        if (objectsInBubble.Count > 0)
        {
            highlightedIndex = 0; // Start with the closest object
        }
        /*
        // Clear the previous list of objects
        objectsInBubble.Clear();

        // Find objects within the bubble using Physics.OverlapSphere
        Collider[] colliders = Physics.OverlapSphere(bubble.transform.position, bubbleRadius);
        foreach (var collider in colliders)
        {
            if (collider.gameObject.GetComponent<SelectableObject>() != null)
            {
                objectsInBubble.Add(collider.gameObject);
            }
        }

        // Update the highlighted index if objects are found
        if (objectsInBubble.Count > 0)
        {
            highlightedIndex = Mathf.Clamp(highlightedIndex, 0, objectsInBubble.Count - 1);
        }*/
    }

    private void NavigateObjectsInBubble()
    {
        // Get the 2D input direction from the joystick
        Vector2 joystickDirection = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, OVRInput.Controller.RTouch);

        // Only proceed if there is input (avoid noise)
        if (joystickDirection.sqrMagnitude > 0.1f)
        {
            // Normalize the joystick direction to get a unit vector
            joystickDirection.Normalize();

            GameObject currentObject = objectsInBubble[highlightedIndex];
            Vector3 currentPosition = currentObject.transform.position;

            float bestDotProduct = -1f; // Best match to joystick direction
            int bestIndex = highlightedIndex; // Default to the current object

            for (int i = 0; i < objectsInBubble.Count; i++)
            {
                if (i == highlightedIndex) continue; // Skip the currently highlighted object

                GameObject candidate = objectsInBubble[i];
                Vector3 candidateDirection = (candidate.transform.position - currentPosition).normalized;

                // Project the candidate direction onto the joystick direction (2D)
                Vector2 projectedDirection = new Vector2(candidateDirection.x, candidateDirection.z);
                float dotProduct = Vector2.Dot(projectedDirection.normalized, joystickDirection);

                // Find the object most aligned with the joystick direction
                if (dotProduct > bestDotProduct)
                {
                    bestDotProduct = dotProduct;
                    bestIndex = i;
                }
            }

            // Highlight the best-matching object
            if (bestIndex != highlightedIndex)
            {
                highlightedIndex = bestIndex;
                HighlightObject(); // Update the visual highlight
            }
        }
    }

    private void HighlightObject()
    {
        // Reset the previously highlighted object
        if (highlightedObject != null)
        {
            highlightedObject.GetComponent<MeshRenderer>().material = originalMaterial;
            highlightedObject = null;
        }

        // Highlight the current object
        if (objectsInBubble.Count > 0)
        {
            highlightedObject = objectsInBubble[highlightedIndex];
            if (highlightedObject != null)
            {
                MeshRenderer renderer = highlightedObject.GetComponent<MeshRenderer>();
                originalMaterial = renderer.material;
                renderer.material = highlightMaterial;
            }
        }
    }

    private void SelectObject()
    {
        if (highlightedObject != null)
        {
            currentSelectedObject = highlightedObject;
        }
    }

    private void ExitPreSelectionMode()
    {
        // Reset highlighting
        if (highlightedObject != null)
        {
            highlightedObject.GetComponent<MeshRenderer>().material = originalMaterial;
            highlightedObject = null;
        }

        objectsInBubble.Clear();
    }

}

  